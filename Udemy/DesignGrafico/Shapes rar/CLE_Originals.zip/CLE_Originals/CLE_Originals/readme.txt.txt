----------
6.28.09

Introduction

Thank you for downloading my resource.  I hope you enjoy the resource and use it well in your future works.  Please follow the following guidelines when using this resource.

----------

Rules

-You may use the resource for personal work which includes signatures, banners, artwork, websites, etc..

-You may NOT use the resource for any commercial work of any kind.  

-You may NOT use the resource for any print of any kind.

-If you so wish to do so, permission from the author is needed and negotiations may take place.

-When resource is used, credit and a link back to my site/DA is much appreciated.

-DO NOT distribute the resource, simply link to the site/DA to where the resource is.

-Any modifications of the resource to turn it as your own is strictly forbidden.

-When resource is used, feel free to post a link to your work on my DA/blog.  I would be glad to see what you have done with it.

----------

Contact Information

Please contact me for any questions/comments/feedback that you may have.

email: creative-le@live.com

----------

Closure

This resource has been brought to you by creative-le.

http://creative-le.com
http://creative-le.com/blog

